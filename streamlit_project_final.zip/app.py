import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

st.set_page_config(
    page_title="Klasifikasi Kebutuhan Pendampingan Belajar",
    page_icon="🎓",
    layout="wide"
)

FEATURES = [
    "StudyHours",
    "Attendance",
    "AssignmentCompletion",
    "OnlineCourses",
    "Discussions",
    "ExamScore",
]

st.title("🎓 Klasifikasi Kebutuhan Pendampingan Belajar")
st.caption("Decision Tree & Random Forest")

# ============================================================
# LOAD DATASET OTOMATIS
# ============================================================
DATA_PATH = Path(__file__).parent / "student_performance_clean.csv"

try:
    df = pd.read_csv(DATA_PATH)
except Exception as e:
    st.error(f"Dataset tidak dapat dibaca: {e}")
    st.stop()

missing = [col for col in FEATURES if col not in df.columns]
if missing:
    st.error("Kolom berikut tidak ditemukan pada dataset: " + ", ".join(missing))
    st.stop()

for col in FEATURES:
    df[col] = pd.to_numeric(df[col], errors="coerce")

df = df.dropna(subset=FEATURES).copy()

# ============================================================
# TARGET
# Sama dengan aturan yang digunakan pada aplikasi sebelumnya:
# jika salah satu indikator melewati batas -> Perlu Pendampingan
# ============================================================
df["Perlu_Pendampingan"] = np.where(
    (df["Attendance"] < 70) |
    (df["AssignmentCompletion"] < 60) |
    (df["ExamScore"] < 60) |
    (df["StudyHours"] < 10),
    "Ya",
    "Tidak"
)

X = df[FEATURES]
y = df["Perlu_Pendampingan"].map({"Tidak": 0, "Ya": 1})

if y.nunique() < 2:
    st.error("Dataset hanya menghasilkan satu kelas target.")
    st.stop()

# ============================================================
# TRAINING
# ============================================================
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

model_dt = DecisionTreeClassifier(random_state=42)
model_rf = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model_dt.fit(X_train, y_train)
model_rf.fit(X_train, y_train)

pred_dt = model_dt.predict(X_test)
pred_rf = model_rf.predict(X_test)

def calculate_metrics(y_true, prediction):
    return {
        "Accuracy": accuracy_score(y_true, prediction),
        "Precision": precision_score(y_true, prediction, zero_division=0),
        "Recall": recall_score(y_true, prediction, zero_division=0),
        "F1-Score": f1_score(y_true, prediction, zero_division=0)
    }

metrics_dt = calculate_metrics(y_test, pred_dt)
metrics_rf = calculate_metrics(y_test, pred_rf)

# ============================================================
# SIDEBAR
# ============================================================
st.sidebar.header("🔮 Data Mahasiswa")

study_hours = st.sidebar.number_input(
    "Study Hours",
    min_value=0.0,
    max_value=100.0,
    value=10.0,
    step=1.0
)

attendance = st.sidebar.number_input(
    "Attendance (%)",
    min_value=0.0,
    max_value=100.0,
    value=70.0,
    step=1.0
)

assignment = st.sidebar.number_input(
    "Assignment Completion (%)",
    min_value=0.0,
    max_value=100.0,
    value=60.0,
    step=1.0
)

online_courses = st.sidebar.number_input(
    "Online Courses",
    min_value=0,
    max_value=100,
    value=5,
    step=1
)

discussions = st.sidebar.number_input(
    "Discussions",
    min_value=0,
    max_value=100,
    value=2,
    step=1
)

exam_score = st.sidebar.number_input(
    "Exam Score",
    min_value=0.0,
    max_value=100.0,
    value=60.0,
    step=1.0
)

selected_model = st.sidebar.selectbox(
    "Pilih algoritma",
    ["Decision Tree", "Random Forest"]
)

model = model_dt if selected_model == "Decision Tree" else model_rf

new_student = pd.DataFrame([{
    "StudyHours": study_hours,
    "Attendance": attendance,
    "AssignmentCompletion": assignment,
    "OnlineCourses": online_courses,
    "Discussions": discussions,
    "ExamScore": exam_score
}])

# ============================================================
# TABS
# ============================================================
tab1, tab2, tab3 = st.tabs([
    "🔮 Prediksi",
    "📊 Evaluasi Model",
    "📋 Dataset"
])

with tab1:
    st.subheader("Hasil Prediksi")

    prediction = int(model.predict(new_student)[0])
    label = "Ya" if prediction == 1 else "Tidak"

    if label == "Ya":
        st.error("## ⚠️ Perlu Pendampingan")
        st.write(
            "Mahasiswa diprediksi **memerlukan pendampingan belajar**."
        )
    else:
        st.success("## ✅ Tidak Perlu Pendampingan")
        st.write(
            "Mahasiswa diprediksi **tidak memerlukan pendampingan khusus**."
        )

    st.subheader("Rekomendasi")

    recommendations = []

    if attendance < 70:
        recommendations.append("Tingkatkan kehadiran mahasiswa.")
    if assignment < 60:
        recommendations.append("Berikan pendampingan penyelesaian tugas.")
    if study_hours < 10:
        recommendations.append("Berikan bimbingan manajemen waktu belajar.")
    if exam_score < 60:
        recommendations.append("Berikan tutoring atau bimbingan akademik.")

    if recommendations:
        for item in recommendations:
            st.write("• " + item)
    else:
        st.write("Tidak ada indikator utama yang melewati batas pendampingan.")

    st.subheader("Data yang dimasukkan")
    st.dataframe(new_student, use_container_width=True, hide_index=True)

    st.info(
        "Aturan klasifikasi: Attendance < 70 ATAU "
        "AssignmentCompletion < 60 ATAU ExamScore < 60 ATAU "
        "StudyHours < 10 → Perlu Pendampingan."
    )

with tab2:
    st.subheader("Perbandingan Performa Model")

    comparison = pd.DataFrame(
        [metrics_dt, metrics_rf],
        index=["Decision Tree", "Random Forest"]
    )

    st.dataframe(
        comparison.style.format("{:.4f}"),
        use_container_width=True
    )

    col1, col2 = st.columns(2)
    col1.metric(
        "Decision Tree Accuracy",
        f"{metrics_dt['Accuracy'] * 100:.2f}%"
    )
    col2.metric(
        "Random Forest Accuracy",
        f"{metrics_rf['Accuracy'] * 100:.2f}%"
    )

    st.subheader(f"Confusion Matrix — {selected_model}")

    prediction_test = pred_dt if selected_model == "Decision Tree" else pred_rf
    cm = confusion_matrix(y_test, prediction_test)

    cm_df = pd.DataFrame(
        cm,
        index=["Aktual Tidak", "Aktual Ya"],
        columns=["Prediksi Tidak", "Prediksi Ya"]
    )

    st.dataframe(cm_df, use_container_width=True)

    st.subheader(f"Classification Report — {selected_model}")

    report = classification_report(
        y_test,
        prediction_test,
        target_names=["Tidak", "Ya"],
        output_dict=True,
        zero_division=0
    )

    st.dataframe(
        pd.DataFrame(report).transpose().round(4),
        use_container_width=True
    )

    if hasattr(model, "feature_importances_"):
        st.subheader("Feature Importance")

        importance = pd.DataFrame({
            "Feature": FEATURES,
            "Importance": model.feature_importances_
        }).sort_values("Importance", ascending=False)

        st.bar_chart(
            importance.set_index("Feature")
        )

with tab3:
    st.subheader("Dataset Penelitian")

    c1, c2 = st.columns(2)
    c1.metric("Jumlah data", f"{len(df):,}")
    c2.metric("Jumlah fitur model", len(FEATURES))

    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )

st.divider()
st.caption(
    "Klasifikasi Kebutuhan Pendampingan Belajar • "
    "Streamlit • Scikit-learn • Pandas"
)
